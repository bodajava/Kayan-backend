import { messaging } from './firebase.js'

const VAPID_KEY = "BIdwa075qs1HDcjyL3ViWmHTvMbpGHCVjleiZ5958ZENJY7Hi-0h0HRfKqdXt7w5eMbGinkt6sAwr1w9ZaW1TJE";
const BACKEND_URL = "http://localhost:3001/send-notification";

let serviceWorkerRegistration = null;

// ✅ Register Service Worker
async function registerServiceWorker() {
    if ("serviceWorker" in navigator) {
        try {
            console.log("Registering SW...");
            window.dashboardLog("Registering Service Worker...", "info");
            // Use relative path to work in subfolders
            serviceWorkerRegistration = await navigator.serviceWorker.register("./firebase-messaging-sw.js");
            console.log("✅ Service Worker registered", serviceWorkerRegistration);
            window.dashboardLog("Service Worker active & registered", "success");
        } catch (err) {
            console.error("❌ SW registration failed", err);
            window.dashboardLog(`SW registration failed: ${err.message}`, "error");
        }
    } else {
        window.dashboardLog("Service Workers not supported in this browser", "error");
    }
}

registerServiceWorker();

// ✅ Get Token
async function getFcmToken() {
    try {
        window.dashboardLog("Requesting permission...", "info");
        const permission = await Notification.requestPermission();

        if (permission !== "granted") {
            alert("Permission denied. Notifications cannot be enabled.");
            window.dashboardLog("Permission denied", "error");
            return;
        }

        window.dashboardLog("Permission granted. Fetching token...", "success");

        // Ensure service worker is ready
        if (!serviceWorkerRegistration) {
            window.dashboardLog("Waiting for Service Worker...", "info");
            serviceWorkerRegistration = await navigator.serviceWorker.ready;
        }

        const token = await messaging.getToken({
            vapidKey: VAPID_KEY,
            serviceWorkerRegistration: serviceWorkerRegistration,
        });

        if (token) {
            console.log("🔥 TOKEN:", token);
            window.dashboardLog("Token generated successfully", "token");
            $("#tokenBox").val(token);
            $("#status").html(`<span class="text-green-400 font-semibold">Ready to receive notifications</span>`);
        } else {
            window.dashboardLog("No token received. Check console.", "error");
        }

    } catch (err) {
        console.error("Error getting token:", err);
        window.dashboardLog(`Error: ${err.message}`, "error");
    }
}

$("#getTokenBtn").click(getFcmToken);

// Export to window for debugging
window.getFcmToken = getFcmToken;

// ✅ Foreground Notifications (IMPORTANT)
messaging.onMessage((payload) => {
    console.log("📨 Foreground message:", payload);
    window.dashboardLog(`New message: ${payload.data?.title || 'No Title'}`, "info");

    if (Notification.permission === "granted") {
        new Notification(payload.data?.title || "New Notification", {
            body: payload.data?.body || "You have a message",
            icon: "/firebase-logo.png",
        });
    }
});

// ✅ Send Notification (Test)
$("#sendTestBtn").click(() => {
    const token = $("#tokenBox").val();

    if (!token) {
        window.dashboardLog("Error: No token available. Get token first.", "error");
        return alert("Token is empty!");
    }

    window.dashboardLog("Sending test request to backend...", "info");

    $.ajax({
        url: BACKEND_URL,
        method: "POST",
        contentType: "application/json",
        data: JSON.stringify({ token }),
        success: () => {
            window.dashboardLog("Push notification triggered successfully", "success");
            $("#status").html(`<span class="text-green-400">Notification sent!</span>`);
        },
        error: (err) => {
            console.error("AJAX Error:", err);
            window.dashboardLog("Failed to reach backend", "error");
            $("#status").html(`<span class="text-red-400">Failed to send (check backend)</span>`);
        }
    });
});
